<?php
class ModelExtensionTotalAutomater extends Model
{
    public function getTotal() {}
}
