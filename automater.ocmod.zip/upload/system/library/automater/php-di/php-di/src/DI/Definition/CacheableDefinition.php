<?php

namespace DI\Definition;

/**
 * Cacheable definition.
 *
 * @author Matthieu Napoli <matthieu@mnapoli.fr>
 */
interface CacheableDefinition extends Definition
{
}
