<?php
namespace AutomaterSDK\Request;

class UploadFileRequest extends BaseRequest
{
    /** @var string */
    protected $filename;

    /** @var string */
    protected $data;

    /**
     * @return string
     */
    public function getFilename()
    {
        return $this->filename;
    }

    /**
     * @param string $filename
     */
    public function setFilename($filename)
    {
        $this->filename = $filename;
    }

    /**
     * @return string
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param string $data
     */
    public function setData($data)
    {
        $this->data = $data;
    }
}