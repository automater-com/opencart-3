<?php
namespace AutomaterSDK\Request;

class CreateDatabaseRequest extends BaseRequest
{
    const TYPE_STANDARD = 1;
    const TYPE_RECURSIVE = 2;

    protected $name;
    protected $type;

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return int
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param int $type
     */
    public function setType($type)
    {
        $this->type = $type;
    }
}