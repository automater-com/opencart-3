<?php
namespace AutomaterSDK\Exception;

class NotFoundException extends \Exception
{

}