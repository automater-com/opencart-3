<?php
namespace AutomaterSDK\Exception;

class UnauthorizedException extends \Exception
{

}