<?php
namespace AutomaterSDK\Response;

class AddNoteToTransactionResponse extends BaseResponse
{

}